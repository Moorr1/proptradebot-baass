#!/bin/bash
# PropTradeBot Launcher for Mac
# Double-click to start. No terminal knowledge needed.

clear
echo "========================================"
echo "  🤖 PropTradeBot Launcher"
echo "========================================"
echo ""

# Get the directory where this script is located
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is required but not installed."
    echo ""
    echo "Please install Python 3 from: https://www.python.org/downloads/"
    echo ""
    read -p "Press Enter to exit..."
    exit 1
fi

PYTHON_VERSION=$(python3 --version 2>&1)
echo "✅ Found $PYTHON_VERSION"

# Check/install required packages
echo ""
echo "📦 Checking dependencies..."
python3 -c "import requests, websockets" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "Installing required packages..."
    pip3 install --user requests websockets 2>&1 | tail -3
fi
echo "✅ Dependencies ready"

# Check for API key
API_KEY_FILE=".api_key"
if [ -f "$API_KEY_FILE" ]; then
    API_KEY=$(cat "$API_KEY_FILE")
    echo ""
    echo "✅ API key loaded"
else
    echo ""
    echo "🔑 Please enter your PropTradeBot API key"
    echo "   (Get it from your dashboard at proptradebot.com)"
    echo ""
    read -p "API Key: " API_KEY
    
    if [ -z "$API_KEY" ]; then
        echo "❌ API key is required"
        read -p "Press Enter to exit..."
        exit 1
    fi
    
    echo "$API_KEY" > "$API_KEY_FILE"
    echo "✅ API key saved"
fi

# Check for bot files
if [ ! -f "server_projectx_v2.py" ]; then
    echo ""
    echo "📥 Downloading PropTradeBot..."
    
    # Download from GitHub or your server
    curl -sL "https://proptradebot.com/downloads/proptradebot-bot-v2.zip" -o bot.zip
    
    if [ -f "bot.zip" ]; then
        unzip -q bot.zip
        rm bot.zip
        echo "✅ Bot downloaded"
    else
        echo "⚠️  Could not download bot automatically."
        echo "   Please download manually from your dashboard."
        read -p "Press Enter to exit..."
        exit 1
    fi
fi

# Export API key
export PTB_API_KEY="$API_KEY"
export PYTHONUNBUFFERED=1

# Start the bot
echo ""
echo "🚀 Starting PropTradeBot..."
echo "   Server: http://localhost:5555"
echo "   Control Panel: http://localhost:5555/control"
echo ""
echo "Press Ctrl+C to stop"
echo "========================================"
echo ""

# Open browser after a short delay
(sleep 3 && open "http://localhost:5555/control") &

# Run the bot
python3 -u server_projectx_v2.py

# If we get here, bot stopped
echo ""
echo "========================================"
echo "  PropTradeBot stopped"
echo "========================================"
read -p "Press Enter to close..."
