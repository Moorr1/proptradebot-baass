PropTradeBot - Quick Start
==========================

1. UNZIP this file to your Desktop (or anywhere)

2. DOUBLE-CLICK "Start PropTradeBot.command"
   - First time: enter your API key (from proptradebot.com dashboard)
   - The bot will download automatically
   - Your browser will open the control panel

3. TRADE
   - The control panel shows bot status, positions, and logs
   - Make sure the Chrome Extension is installed for Discord signals

That's it! No terminal knowledge needed.

---
Support: support@proptradebot.com
