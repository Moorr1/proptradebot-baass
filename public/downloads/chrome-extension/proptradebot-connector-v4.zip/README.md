# PropTradeBot Connector — Chrome Extension v4.0

Connect Discord trading signals to your PropTradeBot instance.

## Features

- **Configurable server URL** — point to any PropTradeBot instance
- **Signal format presets** — Generic (default), TradingView webhook passthrough
- **Discord filters** — author allowlist/blocklist, keyword blocklist
- **Anti-throttle** — service worker keepalive, tab protection, auto-reinject
- **Real-time stats** — alerts sent, uptime, connection status
- **Toggle on/off** — disable without uninstalling

## Installation

1. Download `proptradebot-connector-v4.zip`
2. Open Chrome → `chrome://extensions/`
3. Enable **Developer mode** (toggle top-right)
4. Click **Load unpacked** → select the unzipped folder
5. Pin the extension (click puzzle icon → pin)

## Configuration

Click the extension icon to open the popup:

| Setting | Description |
|---------|-------------|
| **Bot Active** | Master toggle — enable/disable forwarding |
| **Server URL** | Your PropTradeBot `/alert` endpoint |
| **Signal Format** | `Generic` (default), `TradingView` |
| **Allowed Authors** | Only forward messages from these Discord users |
| **Blocked Authors** | Never forward from these users |
| **Blocked Keywords** | Skip messages containing these words |

## Signal Presets

### Generic (Default)
Detects standard trading signals:
- **Entry**: "LONG MES", "BUY MNQ", "ENTER SHORT"
- **Trim**: "TRIM", "TAKE PROFIT", "T1", "T2"
- **Exit**: "FLAT", "ALL OUT", "STOPPED", "EXIT"

### TradingView
For webhook-style alerts or TradingView-formatted text.

## Troubleshooting

| Issue | Fix |
|-------|-----|
| "No response" on test | Check PropTradeBot is running and URL is correct |
| Alerts not firing | Check author is in Allowed list, message isn't blocked by keyword |
| Extension grayed out | Make sure you're on discord.com |
| Stops after idle | Normal — service worker restarts automatically |

## Files

```
chrome-extension/
├── manifest.json          # Extension manifest (Manifest V3)
├── config.js              # Shared config + storage helpers
├── background.js          # Service worker (keepalive, health)
├── content.js             # Discord scraper + signal parser
├── popup.html             # Extension popup UI
├── popup.js               # Popup controller
├── icon16.png             # Icons
├── icon48.png
├── icon128.png
└── proptradebot-connector-v4.zip
```

## Version History

- **v4.0** — Configurable server URL, signal presets, popup UI, stats
- **v3.0** — Anti-throttle service worker, JMoney-only
- **v2.x** — Basic Discord scraper
