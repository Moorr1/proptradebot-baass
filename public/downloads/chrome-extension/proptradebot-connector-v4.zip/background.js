// PropTradeBot Connector — Background Service Worker v4.0
// Keepalive, health checks, config bridge, stats tracking

console.log("🛡️ PropTradeBot Connector BG v4.0 started");

const DISCORD_URL = "https://discord.com";
const HEARTBEAT_ALARM = "ptb-heartbeat";
const HEARTBEAT_INTERVAL_MIN = 0.5; // 30 seconds
const CONTENT_TIMEOUT_MS = 60000;

let lastContentHeartbeat = Date.now();
let discordTabId = null;
let sessionStats = { alertsSent: 0, startTime: Date.now(), lastAlert: null };

// =============================================================================
// TAB MANAGEMENT
// =============================================================================

async function findAndProtectDiscordTab() {
  const tabs = await chrome.tabs.query({ url: "https://discord.com/*" });
  if (tabs.length === 0) {
    discordTabId = null;
    return null;
  }
  const tab = tabs[0];
  discordTabId = tab.id;
  try {
    await chrome.tabs.update(tab.id, { autoDiscardable: false });
  } catch (e) {}
  return tab;
}

async function ensureContentScript(tabId) {
  try {
    const response = await chrome.tabs.sendMessage(tabId, { type: "ping" });
    if (response?.type === "pong") {
      lastContentHeartbeat = Date.now();
      // Update stats from content script
      if (response.alertsSent !== undefined) {
        sessionStats.alertsSent = Math.max(sessionStats.alertsSent, response.alertsSent);
      }
      return true;
    }
  } catch (e) {}

  // Re-inject if needed
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["config.js", "content.js"] });
    lastContentHeartbeat = Date.now();
    return true;
  } catch (e) {
    console.error("❌ Injection failed:", e.message);
    return false;
  }
}

// =============================================================================
// HEARTBEAT
// =============================================================================

async function heartbeatCheck() {
  const tab = await findAndProtectDiscordTab();
  if (!tab) return;

  const since = Date.now() - lastContentHeartbeat;
  if (since > CONTENT_TIMEOUT_MS) {
    console.warn(`🚨 Content silent for ${Math.round(since/1000)}s — reloading`);
    try {
      await chrome.tabs.reload(tab.id);
      lastContentHeartbeat = Date.now();
    } catch (e) {}
    return;
  }

  await ensureContentScript(tab.id);
}

// =============================================================================
// MESSAGE HANDLING
// =============================================================================

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "heartbeat") {
    lastContentHeartbeat = Date.now();
    if (message.alertsSent !== undefined) {
      sessionStats.alertsSent = Math.max(sessionStats.alertsSent, message.alertsSent);
    }
    sendResponse({ type: "ack", timestamp: Date.now() });
    return true;
  }

  if (message.type === "alert_sent") {
    sessionStats.alertsSent++;
    sessionStats.lastAlert = { content: message.content, time: Date.now() };
    sendResponse({ type: "ack" });
    return true;
  }

  if (message.type === "get_stats") {
    sendResponse({
      alertsSent: sessionStats.alertsSent,
      uptime: Math.round((Date.now() - sessionStats.startTime) / 1000),
      lastAlert: sessionStats.lastAlert,
      contentAlive: Date.now() - lastContentHeartbeat < CONTENT_TIMEOUT_MS
    });
    return true;
  }

  if (message.type === "config_update") {
    // Forward to all Discord tabs
    chrome.tabs.query({ url: "https://discord.com/*" }, tabs => {
      tabs.forEach(tab => {
        chrome.tabs.sendMessage(tab.id, message).catch(() => {});
      });
    });
    sendResponse({ ok: true });
    return true;
  }
});

// =============================================================================
// ALARMS
// =============================================================================

chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === HEARTBEAT_ALARM) {
    heartbeatCheck();
  }
});

// =============================================================================
// STARTUP
// =============================================================================

async function initialize() {
  await chrome.alarms.create(HEARTBEAT_ALARM, {
    delayInMinutes: 0.1,
    periodInMinutes: HEARTBEAT_INTERVAL_MIN
  });

  const tab = await findAndProtectDiscordTab();
  if (tab) {
    await ensureContentScript(tab.id);
  }

  console.log("✅ Service worker initialized");
}

// Re-inject on navigation
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (tab.url?.startsWith(DISCORD_URL) && changeInfo.status === "complete") {
    discordTabId = tabId;
    try { await chrome.tabs.update(tabId, { autoDiscardable: false }); } catch (e) {}
    setTimeout(() => ensureContentScript(tabId), 2000);
  }
});

initialize();
