// PropTradeBot Connector — Content Script (Discord)
// Scrapes Discord messages and forwards trading signals to the bot server.
// Supports multiple signal presets: jmoney (internal), generic, tradingview

console.log("🤖 PropTradeBot Connector v4.0 — Content script loaded");
const CONTENT_START_TIME = Date.now();

// Runtime state
let CONFIG = null;
let sentMessages = new Map();
let pendingAlerts = new Map();
let lastKnownText = new Map();
let alertsSent = 0;

const PROCESSED_PREFIX = "processed_";

// =============================================================================
// CONFIG LOADING
// =============================================================================

async function loadRuntimeConfig() {
  const result = await chrome.storage.local.get("ptbConfig");
  CONFIG = result.ptbConfig || {
    serverUrl: "http://localhost:5555/alert",
    enabled: true,
    signalPreset: "generic",
    discord: {
      allowedAuthors: [],
      blockedAuthors: [],
      blockedKeywords: [],
      pollIntervalMs: 500,
      maxMessageAgeMs: 120000,
    },
    dedup: { expiryMs: 15000, debounceMs: 0 },
    debug: false
  };
  if (CONFIG.debug) console.log("📋 Config loaded:", CONFIG);
}

// Listen for config updates from popup/background
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "config_update") {
    CONFIG = message.config;
    if (CONFIG.debug) console.log("📋 Config updated:", CONFIG);
    sendResponse({ ok: true });
    return true;
  }
  if (message.type === "ping") {
    sendResponse({
      type: "pong",
      uptime: Math.round((Date.now() - CONTENT_START_TIME) / 1000),
      messagesTracked: lastKnownText.size,
      alertsSent: alertsSent,
      preset: CONFIG?.signalPreset || "unknown"
    });
    return true;
  }
});

// =============================================================================
// DISCORD MESSAGE EXTRACTION
// =============================================================================

function extractAuthor(element) {
  if (!element) return null;
  const selectors = [
    "[class*=\"username\"]",
    "[class*=\"headerText\"] [class*=\"name\"]",
    "h3 span[class*=\"username\"]",
    "[class*=\"header\"] [class*=\"username\"]",
    "span[class*=\"username\"]"
  ];
  let searchEl = element;
  for (let i = 0; i < 5 && searchEl; i++) {
    for (const selector of selectors) {
      const el = searchEl.querySelector(selector);
      if (el) {
        const name = el.textContent?.trim().toLowerCase();
        if (name) return name;
      }
    }
    searchEl = searchEl.parentElement;
  }
  return null;
}

function extractTimestamp(element) {
  if (!element) return Date.now();
  const timeEls = element.querySelectorAll("time[datetime]");
  for (const el of timeEls) {
    const dt = el.getAttribute("datetime");
    if (dt) {
      const d = new Date(dt);
      if (!isNaN(d.getTime())) return d.getTime();
    }
  }
  // Fallback: parse text patterns
  const text = element.textContent || "";
  const patterns = [
    /Today at (\d{1,2}):(\d{2})\s*(AM|PM)/i,
    /(\d{1,2}):(\d{2})\s*(AM|PM)/i,
  ];
  for (const pattern of patterns) {
    const m = text.match(pattern);
    if (m) {
      const now = new Date();
      let h = parseInt(m[1]);
      const min = parseInt(m[2]);
      const ampm = m[3]?.toUpperCase();
      if (ampm === "PM" && h < 12) h += 12;
      if (ampm === "AM" && h === 12) h = 0;
      const d = new Date(now.getFullYear(), now.getMonth(), now.getDate(), h, min);
      if (d > now) d.setDate(d.getDate() - 1);
      return d.getTime();
    }
  }
  return Date.now();
}

function extractCleanText(element) {
  if (!element) return "";
  const clone = element.cloneNode(true);
  clone.querySelectorAll("button, svg, img, [class*=\"button\"], [class*=\"icon\"]").forEach(el => el.remove());
  let text = (clone.textContent || "").replace(/\s+/g, " ").trim();
  // Strip Discord UI noise
  text = text.replace(/^🔮︱futures chat/, "");
  text = text.replace(/Use the up and down arrow keys.*$/, "");
  text = text.replace(/Click to react.*$/, "");
  text = text.replace(/Copy Message ID.*$/, "");
  text = text.replace(/Mark Unread.*$/, "");
  text = text.replace(/Pin Message.*$/, "");
  return text.trim();
}

// =============================================================================
// SIGNAL PARSERS (by preset)
// =============================================================================

const PARSERS = {
  // JMoney — Richard's personal signal format (internal use only)
  jmoney(text) {
    const upper = text.toUpperCase();
    const results = [];

    // Entry: "ENTERING LONG MES @ 5234" or "LONG MES 5234"
    if (/ENTERING|ENTRY|LONG\s+MES|SHORT\s+MES|ES\s+LONG|ES\s+SHORT/.test(upper)) {
      const priceMatch = text.match(/\b([5-9]\d{3})(?:\.\d+)?\b/);
      const dirMatch = upper.match(/(LONG|SHORT)/);
      if (dirMatch) {
        const code = priceMatch ? `ENTRY_${dirMatch[1]}_${priceMatch[1]}` : `ENTRY_${dirMatch[1]}`;
        results.push(code);
      }
    }

    // Trim: "TRIM 3/4" or "FIRST TARGET" or "SECOND TARGET"
    if (/TRIM|TARGET/.test(upper)) {
      const has34 = upper.includes("3/4");
      const has18 = upper.includes("1/8") || upper.includes("3/8");
      const hasSecond = upper.includes("SECOND") || upper.includes("2ND");
      if (has34) results.push("TRIM_3/4");
      if (has18 || hasSecond) results.push("TRIM_1/8");
      if (results.length === 0 && upper.includes("TRIM")) results.push("TRIM_3/4");
    }

    // Exit: "FLAT", "ALL OUT", "STOPPED", "CLOSE" (but not "5m close 6630")
    const isExitClose = upper.includes("CLOSE") && !/\d+M?\s+CLOSE\s+\d/.test(upper) && !/CLOSE\s+\d{4}/.test(upper);
    if (/FLAT|ALL\s+OUT|STOPPED|STOP\s+HIT|EXIT/.test(upper) || isExitClose) {
      results.push("EXIT");
    }

    return results.length ? (results.length === 1 ? results[0] : results) : null;
  },

  // Generic — public-facing preset for any signal provider
  generic(text) {
    const upper = text.toUpperCase();
    const results = [];

    // Entry patterns
    const entryPatterns = [
      { regex: /\b(BUY|LONG|ENTER)\b.*\b(MES|MNQ|ES|NQ)\b/i, type: "ENTRY" },
      { regex: /\b(MES|MNQ|ES|NQ)\b.*\b(BUY|LONG|ENTER)\b/i, type: "ENTRY" },
      { regex: /\bGO\s+LONG\b|\bLONG\s+ENTRY\b/i, type: "ENTRY" },
    ];
    for (const p of entryPatterns) {
      if (p.regex.test(text)) {
        const dir = upper.includes("SHORT") || upper.includes("SELL") ? "SHORT" : "LONG";
        const price = text.match(/\b(\d{3,5}(?:\.\d+)?)\b/);
        results.push(price ? `ENTRY_${dir}_${price[1]}` : `ENTRY_${dir}`);
        break;
      }
    }

    // Trim / Target patterns (T1-T4 priority order)
    const trimPatterns = [
      { regex: /\b1ST\s+TARGET\b|\bFIRST\s+TARGET\b|\bT1\b/i, type: "TRIM_T1" },
      { regex: /\b2ND\s+TARGET\b|\bSECOND\s+TARGET\b|\bT2\b/i, type: "TRIM_T2" },
      { regex: /\b3RD\s+TARGET\b|\bTHIRD\s+TARGET\b|\bT3\b/i, type: "TRIM_T3" },
      { regex: /\b4TH\s+TARGET\b|\bFOURTH\s+TARGET\b|\bT4\b/i, type: "TRIM_T4" },
      { regex: /\bTRIM\b|\bTAKE\s+PROFIT\b|\bTP\d?\b/i, type: "TRIM" },
    ];
    for (const p of trimPatterns) {
      if (p.regex.test(text)) {
        results.push(p.type);
        break;
      }
    }

    // Exit patterns
    const exitPatterns = [
      { regex: /\bFLAT\b|\bALL\s+OUT\b|\bCLOSE\s+ALL\b/i, type: "EXIT" },
      { regex: /\bSTOPPED\b|\bSTOP\s+HIT\b|\bSTOP\s+OUT\b/i, type: "EXIT_STOP" },
      { regex: /\bSELL\b.*\bALL\b|\bEXIT\b/i, type: "EXIT" },
    ];
    for (const p of exitPatterns) {
      if (p.regex.test(text)) {
        results.push(p.type);
        break;
      }
    }

    return results.length ? (results.length === 1 ? results[0] : results) : null;
  },

  // TradingView — webhook-style alerts (usually come via webhook, but handle text too)
  tradingview(text) {
    const upper = text.toUpperCase();
    const ticker = text.match(/\b(MES|MNQ|ES|NQ)[A-Z0-9]*\b/i);
    const dir = upper.includes("LONG") || upper.includes("BUY") ? "LONG"
              : upper.includes("SHORT") || upper.includes("SELL") ? "SHORT"
              : null;
    if (!dir) return null;
    const price = text.match(/\b(\d{3,5}(?:\.\d+)?)\b/);
    return ticker ? `ENTRY_${dir}_${ticker[1]}_${price ? price[1] : ""}` : `ENTRY_${dir}`;
  }
};

function parseSignal(text, preset) {
  const parser = PARSERS[preset] || PARSERS.generic;
  return parser(text);
}

// =============================================================================
// FILTERING
// =============================================================================

function isAllowedAuthor(author) {
  if (!author) return true;
  const lower = author.toLowerCase();
  const blocked = CONFIG.discord.blockedAuthors || [];
  for (const b of blocked) {
    if (lower.includes(b.toLowerCase())) return false;
  }
  const allowed = CONFIG.discord.allowedAuthors || [];
  if (allowed.length === 0) return true; // No filter = allow all
  for (const a of allowed) {
    if (lower.includes(a.toLowerCase())) return true;
  }
  return false;
}

function containsBlockedKeyword(text) {
  if (!text) return false;
  const lower = text.toLowerCase();
  const keywords = CONFIG.discord.blockedKeywords || [];
  for (const kw of keywords) {
    if (lower.includes(kw.toLowerCase())) return true;
  }
  return false;
}

function isValidTradingMessage(text) {
  if (!text || text.length < 5) return false;
  const upper = text.toUpperCase();
  const keywords = ["MES", "ES", "MNQ", "NQ", "ENTRY", "TRIM", "TARGET", "FLAT",
                    "STOP", "LONG", "SHORT", "EXIT", "ENTERING", "BUY", "SELL", "ALL OUT"];
  return keywords.some(kw => upper.includes(kw));
}

// =============================================================================
// ALERT SENDING
// =============================================================================

function wasSentRecently(content) {
  const ts = sentMessages.get(content);
  if (!ts) return false;
  return (Date.now() - ts) < (CONFIG.dedup?.expiryMs || 15000);
}

function isAlreadyProcessed(element) {
  if (!element?.getAttribute) return true;
  const id = element.getAttribute("id") || element.getAttribute("data-list-item-id");
  return id && sentMessages.has(PROCESSED_PREFIX + id);
}

function markAsProcessed(element) {
  if (!element?.getAttribute) return;
  const id = element.getAttribute("id") || element.getAttribute("data-list-item-id");
  if (id) sentMessages.set(PROCESSED_PREFIX + id, Date.now());
}

function sendAlert(content, fullText, element, timestamp) {
  if (!CONFIG.enabled) return;
  markAsProcessed(element);

  const payload = {
    source: "discord",
    content: content,
    text: fullText,
    timestamp: timestamp,
    capturedAt: Date.now(),
    preset: CONFIG.signalPreset
  };

  console.log(`📤 [${new Date().toISOString()}] Sending: ${content}`);

  fetch(CONFIG.serverUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  })
  .then(r => r.json().catch(() => ({ ok: r.ok })))
  .then(data => {
    alertsSent++;
    console.log(`✅ Server response:`, data);
  })
  .catch(err => console.error(`❌ Send failed:`, err));
}

function sendAlertDebounced(content, fullText, element, timestamp) {
  const existing = pendingAlerts.get(content);
  if (existing) {
    clearTimeout(existing.timer);
    console.log(`⏳ Duplicate detected, resetting timer: ${content}`);
  }

  const timer = setTimeout(() => {
    pendingAlerts.delete(content);
    if (wasSentRecently(content)) {
      console.log(`🔄 Already sent recently: ${content}`);
      return;
    }
    sentMessages.set(content, Date.now());
    sendAlert(content, fullText, element, timestamp);
  }, CONFIG.dedup?.debounceMs || 0);

  pendingAlerts.set(content, { timer, fullText, element, timestamp });
}

// =============================================================================
// MESSAGE PROCESSING
// =============================================================================

function processMessageElement(element) {
  if (!CONFIG.enabled) return;
  if (isAlreadyProcessed(element)) return;

  const author = extractAuthor(element);
  if (!isAllowedAuthor(author)) {
    markAsProcessed(element);
    return;
  }

  const text = extractCleanText(element);
  if (CONFIG.debug) console.log("📄 Raw text:", text);

  if (containsBlockedKeyword(text)) {
    if (CONFIG.debug) console.log("🚫 Blocked keyword");
    markAsProcessed(element);
    return;
  }

  if (!isValidTradingMessage(text)) return;

  const signal = parseSignal(text, CONFIG.signalPreset);
  if (CONFIG.debug) console.log("📝 Signal:", signal, "from text:", text.substring(0, 80));
  if (!signal) return;

  const msgTimestamp = extractTimestamp(element);
  const age = Date.now() - msgTimestamp;
  if (age > (CONFIG.discord.maxMessageAgeMs || 120000)) {
    console.log(`⏭️ Stale message (${Math.round(age/1000)}s old): ${signal}`);
    markAsProcessed(element);
    return;
  }

  const signals = Array.isArray(signal) ? signal : [signal];
  for (const s of signals) {
    console.log(`🔍 [${author || "?"}] ${s}`);
    sendAlertDebounced(s, text, element, msgTimestamp);
  }
}

// =============================================================================
// MONITORING
// =============================================================================

function pollForNewContent() {
  if (!CONFIG.enabled) return;
  const container = document.querySelector("[class*=\"messages\"]") ||
                    document.querySelector("main") || document.body;
  if (!container) return;

  const elements = Array.from(container.querySelectorAll("[class*=\"message\"], [role=\"article\"]")).slice(-10);

  elements.forEach(el => {
    const id = el.getAttribute("id") || el.getAttribute("data-list-item-id");
    if (!id) return;
    const currentText = el.textContent || "";
    const previousText = lastKnownText.get(id) || "";

    if (currentText.length > previousText.length && previousText.length > 0) {
      const newContent = currentText.slice(previousText.length).trim();
      if (newContent.length > 5) {
        console.log(`🔄 [POLL] Text change in ${id}: "${newContent.substring(0, 60)}..."`);
        processMessageElement(el);
      }
    }
    lastKnownText.set(id, currentText);
  });

  // Cleanup old entries
  if (lastKnownText.size > 50) {
    const keys = Array.from(lastKnownText.keys());
    keys.slice(0, keys.length - 50).forEach(k => lastKnownText.delete(k));
  }
}

function startMonitoring() {
  console.log(`👀 Monitoring Discord — preset: ${CONFIG.signalPreset}`);

  const observer = new MutationObserver(mutations => {
    if (!CONFIG.enabled) return;
    mutations.forEach(mutation => {
      mutation.addedNodes.forEach(node => {
        if (node.nodeType !== 1) return;
        const elements = [];
        if (node.classList?.toString().includes("message") || node.getAttribute("role") === "article") {
          elements.push(node);
        }
        node.querySelectorAll("[class*=\"message\"], [role=\"article\"]").forEach(el => {
          if (!isAlreadyProcessed(el)) elements.push(el);
        });
        elements.forEach(el => processMessageElement(el));
      });
    });
  });

  const container = document.querySelector("[class*=\"messages\"]") ||
                    document.querySelector("main") || document.body;
  observer.observe(container, { childList: true, subtree: true });

  // Polling fallback
  setInterval(pollForNewContent, CONFIG.discord.pollIntervalMs || 500);

  // Snapshot existing messages
  setTimeout(() => {
    container.querySelectorAll("[class*=\"message\"], [role=\"article\"]").forEach(el => {
      const id = el.getAttribute("id") || el.getAttribute("data-list-item-id");
      if (id) lastKnownText.set(id, el.textContent || "");
    });
    console.log(`📸 Snapshot: ${lastKnownText.size} messages`);
  }, 500);

  console.log("✅ Observer + polling active");
}

// =============================================================================
// INITIALIZATION
// =============================================================================

async function init() {
  await loadRuntimeConfig();

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", startMonitoring);
  } else {
    startMonitoring();
  }

  // Heartbeat to background
  setInterval(() => {
    try {
      chrome.runtime.sendMessage({
        type: "heartbeat",
        timestamp: Date.now(),
        alertsSent: alertsSent
      });
    } catch (e) {
      console.warn("⚠️ Extension context lost");
    }
  }, 10000);

  // Visibility change — aggressive scan
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") {
      console.log("👁️ Tab visible — scanning");
      pollForNewContent();
      setTimeout(pollForNewContent, 500);
      setTimeout(pollForNewContent, 1000);
    }
  });
}

init();
