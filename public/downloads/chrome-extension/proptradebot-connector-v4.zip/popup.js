// Popup UI controller for PropTradeBot Connector

let currentConfig = null;

// Initialize popup
document.addEventListener("DOMContentLoaded", async () => {
  currentConfig = await loadConfig();
  renderConfig(currentConfig);
  startStatsUpdate();
  
  // Event listeners
  document.getElementById("enabledToggle").addEventListener("change", onToggle);
  document.getElementById("saveBtn").addEventListener("click", onSave);
  document.getElementById("testBtn").addEventListener("click", onTest);
  
  // Preset buttons
  document.querySelectorAll(".preset-btn").forEach(btn => {
    btn.addEventListener("click", () => onPresetSelect(btn.dataset.preset));
  });
  
  // Tag inputs
  setupTagInput("allowedAuthors", currentConfig.discord.allowedAuthors);
  setupTagInput("blockedAuthors", currentConfig.discord.blockedAuthors);
  setupTagInput("blockedKeywords", currentConfig.discord.blockedKeywords);
});

function renderConfig(config) {
  document.getElementById("enabledToggle").checked = config.enabled;
  document.getElementById("serverUrl").value = config.serverUrl;
  
  // Update status dot
  const dot = document.getElementById("statusDot");
  dot.classList.toggle("offline", !config.enabled);
  
  // Update preset buttons
  document.querySelectorAll(".preset-btn").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.preset === config.signalPreset);
  });
  
  // Update preset description
  const desc = document.getElementById("presetDesc");
  const descriptions = {
    jmoney: "Personal preset — not for distribution",
    generic: "Standard entry/trim/exit patterns",
    tradingview: "Webhook passthrough format"
  };
  desc.textContent = descriptions[config.signalPreset] || "";
}

function onPresetSelect(preset) {
  currentConfig.signalPreset = preset;
  renderConfig(currentConfig);
}

function onToggle(e) {
  currentConfig.enabled = e.target.checked;
  // Send to background immediately for responsiveness
  chrome.runtime.sendMessage({ type: "config_update", config: currentConfig });
  renderConfig(currentConfig);
}

async function onSave() {
  currentConfig.serverUrl = document.getElementById("serverUrl").value.trim();
  currentConfig.discord.allowedAuthors = getTags("allowedAuthors");
  currentConfig.discord.blockedAuthors = getTags("blockedAuthors");
  currentConfig.discord.blockedKeywords = getTags("blockedKeywords");
  
  await saveConfig(currentConfig);
  
  // Notify background and content scripts
  chrome.runtime.sendMessage({ type: "config_update", config: currentConfig });
  
  // Show feedback
  const btn = document.getElementById("saveBtn");
  const original = btn.textContent;
  btn.textContent = "✅ Saved!";
  btn.style.background = "#43b581";
  setTimeout(() => {
    btn.textContent = original;
    btn.style.background = "";
  }, 1500);
}

async function onTest() {
  const url = document.getElementById("serverUrl").value.trim();
  const btn = document.getElementById("testBtn");
  btn.textContent = "⏳ Testing...";
  
  try {
    const response = await fetch(url.replace("/alert", "/health"), { 
      method: "GET",
      signal: AbortSignal.timeout(5000)
    });
    if (response.ok) {
      const data = await response.json();
      btn.textContent = `✅ Connected (${data.active_positions || 0} positions)`;
      btn.style.background = "#43b581";
    } else {
      btn.textContent = `⚠️ HTTP ${response.status}`;
      btn.style.background = "#faa61a";
    }
  } catch (err) {
    btn.textContent = "❌ No response";
    btn.style.background = "#f04747";
  }
  
  setTimeout(() => {
    btn.textContent = "🧪 Test Connection";
    btn.style.background = "";
  }, 3000);
}

// Tag input helpers
function setupTagInput(containerId, initialTags) {
  const container = document.getElementById(containerId);
  const input = container.querySelector("input");
  
  // Render initial tags
  initialTags.forEach(tag => addTag(container, tag));
  
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault();
      const value = input.value.trim();
      if (value) {
        addTag(container, value);
        input.value = "";
      }
    }
    if (e.key === "Backspace" && !input.value) {
      const tags = container.querySelectorAll(".tag");
      if (tags.length > 0) tags[tags.length - 1].remove();
    }
  });
  
  input.addEventListener("blur", () => {
    const value = input.value.trim();
    if (value) {
      addTag(container, value);
      input.value = "";
    }
  });
}

function addTag(container, text) {
  // Prevent duplicates
  const existing = Array.from(container.querySelectorAll(".tag")).map(t => t.dataset.value);
  if (existing.includes(text.toLowerCase())) return;
  
  const tag = document.createElement("span");
  tag.className = "tag";
  tag.dataset.value = text.toLowerCase();
  tag.innerHTML = `${text} <span class="remove">×</span>`;
  tag.querySelector(".remove").addEventListener("click", () => tag.remove());
  container.insertBefore(tag, container.querySelector("input"));
}

function getTags(containerId) {
  const container = document.getElementById(containerId);
  return Array.from(container.querySelectorAll(".tag")).map(t => t.dataset.value);
}

// Stats update
function startStatsUpdate() {
  updateStats();
  setInterval(updateStats, 2000);
}

async function updateStats() {
  try {
    const response = await chrome.runtime.sendMessage({ type: "get_stats" });
    if (response) {
      document.getElementById("statAlerts").textContent = response.alertsSent || 0;
      document.getElementById("statUptime").textContent = formatDuration(response.uptime || 0);
    }
  } catch (e) {
    // Extension context may not be ready
  }
}

function formatDuration(seconds) {
  if (seconds < 60) return `${seconds}s`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
  return `${Math.floor(seconds / 3600)}h ${Math.floor((seconds % 3600) / 60)}m`;
}
