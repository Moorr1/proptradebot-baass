// PropTradeBot Connector 5.0 — background worker.
// The ONLY part that talks to the app: requests go out with this extension's origin
// (chrome-extension://…), which the app allows for /signal and /health only. The Discord
// page itself can't reach the app. The passphrase comes from the popup (copied from the
// app's Alerts tab) and is sent with every message.
const APP = "http://localhost:5555";
const state = { lastSent: null, lastResult: "", lastError: "", appOk: null, page: null, counts: {} };

async function passphrase() {
  const { passphrase } = await chrome.storage.local.get("passphrase");
  return passphrase || "";
}

async function post(body) {
  const pp = await passphrase();
  if (!pp) { state.lastError = "No passphrase: paste it from PropTradeBot → Alerts into this Connector."; return null; }
  try {
    const r = await fetch(APP + "/signal", { method: "POST", headers: { "Content-Type": "application/json" },
                                              body: JSON.stringify(Object.assign({ passphrase: pp }, body)) });
    const d = await r.json().catch(() => ({}));
    state.appOk = true;
    if (r.status === 401) state.lastError = "PropTradeBot rejected the passphrase. Copy it again from the Alerts tab.";
    else state.lastError = "";
    return { status: r.status, d };
  } catch (e) {
    state.appOk = false;
    state.lastError = "Can't reach PropTradeBot on this Mac. Is the app open?";
    return null;
  }
}

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg && msg.type === "signal") {
    post(msg.payload).then(res => {
      state.lastSent = Date.now();
      const kind = !res ? "not delivered" : res.status === 404 ? "not a connected provider"
        : res.d.duplicate ? "duplicate" : res.d.shadow ? "shadow" : res.d.acted ? "traded"
        : (res.d.classification && res.d.classification.kind) || ("HTTP " + res.status);
      state.lastResult = kind;
      state.counts[kind] = (state.counts[kind] || 0) + 1;
      chrome.storage.local.set({ ptbState: state });
    });
  } else if (msg && msg.type === "heartbeat") {
    state.page = { readable: msg.readable, inChannel: msg.inChannel, stats: msg.stats, at: Date.now() };
    post({ heartbeat: true, readable: msg.readable !== false }).then(() => chrome.storage.local.set({ ptbState: state }));
  } else if (msg && msg.type === "page") {
    state.page = Object.assign(state.page || {}, { lastIssue: msg.kind, stats: msg.stats, at: Date.now() });
    chrome.storage.local.set({ ptbState: state });
  } else if (msg && msg.type === "status") {
    reply(state);
  }
  return false;
});
