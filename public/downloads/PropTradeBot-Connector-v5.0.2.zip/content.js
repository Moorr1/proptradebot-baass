// PropTradeBot Connector 5.0 — Discord page reader.
// Reads NEW messages on the open Discord channel and hands them to the background worker,
// which sends them to the PropTradeBot app on this Mac. No parsing, no filtering by name:
// the app decides what (if anything) a message means. Identification is by Discord's own
// IDs (channel, message, author), never by display names.
//
// Discord markup relied on (long-standing):
//   <li id="chat-messages-<channelId>-<messageId>">         one message row
//   <div id="message-content-<messageId>">                   the message text
//   <div id="message-accessories-<messageId>">               embeds / attachments
//   <img src="https://cdn.discordapp.com/avatars/<userId>/…"> author avatar (group start only)
//   <time datetime="…">                                      when it was sent
// A follow-on message in a group has no avatar; its author is the group's first message's.
// If the author can't be identified, the message is NOT sent (reported as 'no author').
(function () {
  "use strict";
  const ROW = /^chat-messages-(\d+)-(\d+)$/;
  const AVATAR = /\/avatars\/(\d+)\//;
  const MAX_AGE_MS = 120000;            // older messages (history, scrolling) are never sent
  const seen = new Set();
  const started = Date.now();
  const stats = { rows: 0, sent: 0, noAuthor: 0, old: 0, repeats: 0 };
  // When YOU post, Discord first shows the message with a temporary id, then swaps in the
  // confirmed one: two rows, same author/channel/text, ~0.1 s apart (seen in Richard's VM test).
  // Send identical text from the same author in the same channel only once per few seconds.
  const REPEAT_MS = 5000;
  const recentText = new Map();

  function rowIds(li) {
    const m = ROW.exec(li && li.id || "");
    return m ? { channelId: m[1], messageId: m[2] } : null;
  }

  // Avatars inside these belong to someone else: the replied-to user, a mention, an embed's
  // author icon. Only the row's own header avatar identifies the author.
  const NOT_AUTHOR = "[id^='message-reply-context-'], [id^='message-content-'], [id^='message-accessories-']";

  function avatarAuthor(li) {
    for (const img of li.querySelectorAll("img")) {
      if (img.closest(NOT_AUTHOR)) continue;
      const m = AVATAR.exec(img.getAttribute("src") || "");
      if (m) return m[1];
    }
    return null;
  }

  function startsGroup(li) {
    // a group's first row carries the author header (name, and usually the avatar)
    return !!li.querySelector("[id^='message-username-'], h3");
  }

  function authorId(li) {
    // The row itself if it starts a group, else the nearest earlier row that starts one.
    // Stop at the FIRST group start: if its avatar has no user ID (default avatar), the
    // author is unknown — never borrow an earlier group's author.
    for (let el = li, i = 0; el && i < 40; el = el.previousElementSibling, i++) {
      if (!rowIds(el)) continue;
      if (startsGroup(el)) return avatarAuthor(el);
    }
    return null;
  }

  function cleanText(el) {
    if (!el) return "";
    const c = el.cloneNode(true);
    c.querySelectorAll("button, svg, [aria-hidden='true'], time").forEach(x => x.remove());
    return (c.textContent || "").replace(/\s+/g, " ").trim();
  }

  function bodyText(li, messageId) {
    const content = cleanText(li.querySelector("#message-content-" + messageId));
    const extra = cleanText(li.querySelector("#message-accessories-" + messageId));
    return [content, extra].filter(Boolean).join(" ").trim();
  }

  function sentAt(li) {
    const t = li.querySelector("time[datetime]");
    const d = t ? new Date(t.getAttribute("datetime")) : null;
    return d && !isNaN(d.getTime()) ? d.getTime() : null;
  }

  function handle(li) {
    const ids = rowIds(li);
    if (!ids || seen.has(ids.messageId)) return;
    seen.add(ids.messageId);
    stats.rows++;
    const ts = sentAt(li);
    if (ts === null || Date.now() - ts > MAX_AGE_MS || ts < started - MAX_AGE_MS) { stats.old++; return; }
    const author = authorId(li);
    const text = bodyText(li, ids.messageId);
    if (!text) return;
    if (!author) { stats.noAuthor++; report("no-author", ids); return; }
    const key = ids.channelId + "|" + author + "|" + text;
    const prev = recentText.get(key);
    recentText.set(key, ts);
    if (prev !== undefined && Math.abs(ts - prev) < REPEAT_MS) { stats.repeats++; return; }
    stats.sent++;
    chrome.runtime.sendMessage({
      type: "signal",
      payload: { channel_id: ids.channelId, author_id: author, message_id: ids.messageId,
                 text: text, timestamp: ts / 1000 }
    });
  }

  function report(kind, ids) {
    chrome.runtime.sendMessage({ type: "page", kind, ids: ids || null, stats: Object.assign({}, stats) });
  }

  function scan(root) {
    if (!root || !root.querySelectorAll) return;
    if (rowIds(root)) handle(root);
    root.querySelectorAll("li[id^='chat-messages-']").forEach(handle);
  }

  // Messages already on screen when the page loads are history: mark them seen, never send.
  document.querySelectorAll("li[id^='chat-messages-']").forEach(li => {
    const ids = rowIds(li); if (ids) seen.add(ids.messageId);
  });
  new MutationObserver(muts => {
    for (const m of muts) m.addedNodes.forEach(n => { if (n.nodeType === 1) scan(n); });
  }).observe(document.body, { childList: true, subtree: true });

  // Heartbeat: lets the app show "Connector last heard from …" even on a quiet channel,
  // and says whether this page looks readable (message rows found).
  // Discord is a single-page app: the Connector loads on every discord.com page (login, home,
  // channels) because moving into a channel never reloads the page. Only a channel page can be
  // 'readable'; elsewhere it reports 'no channel open' instead of a false 'can't read'.
  function beat() {
    const inChannel = /^\/channels\/[^/]+\/\d+/.test(location.pathname);
    const readable = inChannel ? document.querySelectorAll("li[id^='chat-messages-']").length > 0 : null;
    chrome.runtime.sendMessage({ type: "heartbeat", readable, inChannel, stats: Object.assign({}, stats),
                                 channel: (location.pathname.split("/")[3] || "") });
  }
  setInterval(beat, 30000);
  setTimeout(beat, 3000);

  if (window.__PTB_TEST__) window.__PTB_TEST__.api = { rowIds, authorId, bodyText, sentAt, stats };
})();
