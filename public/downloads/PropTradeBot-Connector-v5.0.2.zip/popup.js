const $ = id => document.getElementById(id);
function ago(t) { if (!t) return "never"; const s = Math.round((Date.now() - t) / 1000); return s < 90 ? s + "s ago" : Math.round(s / 60) + " min ago"; }
function set(id, text, cls) { $(id).textContent = text; $(id).className = cls || ""; }

chrome.storage.local.get("passphrase").then(({ passphrase }) => { if (passphrase) set("saved", "saved"); });
$("save").onclick = async () => {
  const v = $("pp").value.trim(); if (!v) return;
  await chrome.storage.local.set({ passphrase: v }); $("pp").value = ""; set("saved", "saved", "ok");
};
async function refresh() {
  let st = await chrome.runtime.sendMessage({ type: "status" }).catch(() => null);
  if (!st) st = (await chrome.storage.local.get("ptbState")).ptbState || {};
  set("app", st.appOk === true ? "connected" : st.appOk === false ? "not reachable — is PropTradeBot open?" : "not contacted yet",
      st.appOk === true ? "ok" : st.appOk === false ? "bad" : "warn");
  const p = st.page;
  if (!p) set("page", "not running on a Discord tab yet — open discord.com and press Cmd-R once", "warn");
  else if (p.inChannel === false) set("page", "open the signal channel in Discord", "warn");
  else if (!p.readable) set("page", "can't read this page (Discord may have changed) — " + ago(p.at), "bad");
  else set("page", `reading (${(p.stats && p.stats.sent) || 0} sent, ${(p.stats && p.stats.noAuthor) || 0} without author) — ${ago(p.at)}`, "ok");
  set("last", st.lastSent ? `${ago(st.lastSent)} — ${st.lastResult}` : "none yet", "muted");
  set("err", st.lastError || "");
}
refresh(); setInterval(refresh, 2000);
