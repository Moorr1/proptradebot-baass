// Shared configuration for PropTradeBot Chrome Extension
// Loaded by both popup and content script

const DEFAULT_CONFIG = {
  serverUrl: "http://localhost:5555/alert",
  enabled: true,
  signalPreset: "generic",  // "generic" (default)
  
  // Discord-specific filters
  discord: {
    allowedAuthors: ["jmoney", "j money", "j-money", "moorr1", "moorr", "richard", "rich", "optionsful"],
    blockedAuthors: ["twinsight bot", "twinsight"],
    blockedKeywords: ["backtest", "watchlist", "backtested", "plan:", "overnight", "weekly plan", "monthly plan", "idea:", "setup:", "scan", "screener", "(scanner)", "-c]"],
    allowedChannels: [],  // empty = all channels
    pollIntervalMs: 500,
    maxMessageAgeMs: 120000,
  },
  
  // Alert deduplication
  dedup: {
    expiryMs: 15000,
    debounceMs: 0
  },
  
  // Debug
  debug: false
};

// Load config from chrome.storage
async function loadConfig() {
  const result = await chrome.storage.local.get("ptbConfig");
  if (result.ptbConfig) {
    // Deep merge with defaults
    return deepMerge({...DEFAULT_CONFIG}, result.ptbConfig);
  }
  return {...DEFAULT_CONFIG};
}

// Save config to chrome.storage
async function saveConfig(config) {
  await chrome.storage.local.set({ ptbConfig: config });
}

// Deep merge helper
function deepMerge(target, source) {
  for (const key in source) {
    if (source[key] && typeof source[key] === "object" && !Array.isArray(source[key])) {
      target[key] = deepMerge(target[key] || {}, source[key]);
    } else {
      target[key] = source[key];
    }
  }
  return target;
}

// Export for both module and script tag contexts
if (typeof module !== "undefined" && module.exports) {
  module.exports = { DEFAULT_CONFIG, loadConfig, saveConfig, deepMerge };
}
